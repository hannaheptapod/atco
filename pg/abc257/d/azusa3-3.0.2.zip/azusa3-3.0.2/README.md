Azusa 3
=============

Free Google Slides & Keynote Theme

- <https://azusa3.sanographix.net>

# Download & Install

## For Keynote

### System requirements

- Keynote v10.0 (for macOS)

### Install

- <https://github.com/sanographix/azusa3/archive/v3.0.2.zip>

1. Unzip the file
2. Open `azusa3.kth`
3. Select "Add to theme selector".

## For Google Slides

- <https://docs.google.com/presentation/d/1zCNQDgWZHHwhHh2pWnv5UGHylEwhB9rMUqAeQPtXZnk/template/preview>


# Author

#### @sanographix

* <https://www.sanographix.net/>
* Twitter: [@sanographix](https://twitter.com/sanographix)
* GitHub: [sanographix](https://github.com/sanographix)
